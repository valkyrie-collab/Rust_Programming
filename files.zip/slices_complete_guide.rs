// ============================================
// SLICES - Complete Explanation
// ============================================

/*
SLICE = A reference to a CONTIGUOUS SEQUENCE of elements
        without taking ownership

Key word: CONTIGUOUS (elements are next to each other)
*/

// ============================================
// PART 1: What is a Slice?
// ============================================

fn what_is_slice() {
    /*
    A slice is like taking a WINDOW or VIEW into existing data
    
    Without slice:
    let data = vec![1, 2, 3, 4, 5];
    // You have the whole vector
    
    With slice:
    let slice = &data[1..4];
    // You're looking at only elements 1, 2, 3
    // You don't own them, just borrowing the view
    */
    
    let data = vec![1, 2, 3, 4, 5];
    //  ^^^^
    //  Owned vector (you own all 5 elements)
    
    let slice = &data[1..4];
    //  ^^^^^
    //  Slice - you're viewing only elements at indices 1, 2, 3
    //  You don't own them
    //  Just a window/reference to that part of the vector
    
    println!("Slice: {:?}", slice);  // [2, 3, 4]
}

// ============================================
// PART 2: Creating Slices - Different Ways
// ============================================

fn creating_slices() {
    let data = vec![10, 20, 30, 40, 50];
    //  ^^^^
    //  Original data
    
    // Way 1: Slice the entire vector
    let slice1 = &data[..];
    //           ^^^^
    //           [10, 20, 30, 40, 50]
    println!("Entire: {:?}", slice1);
    
    // Way 2: Slice from start to index 3
    let slice2 = &data[..3];
    //           ^^^^^^
    //           [10, 20, 30]
    println!("Start to 3: {:?}", slice2);
    
    // Way 3: Slice from index 1 to end
    let slice3 = &data[1..];
    //           ^^^^^^
    //           [20, 30, 40, 50]
    println!("1 to end: {:?}", slice3);
    
    // Way 4: Slice from index 1 to index 4
    let slice4 = &data[1..4];
    //           ^^^^^^^
    //           [20, 30, 40]
    println!("1 to 4: {:?}", slice4);
    
    // Way 5: From array
    let array = [1, 2, 3, 4, 5];
    let array_slice = &array[1..3];
    //                 ^^^^^^^^^^^
    //                 [2, 3]
    println!("Array slice: {:?}", array_slice);
}

// ============================================
// PART 3: Slice Notation - Understanding [start..end]
// ============================================

fn slice_notation() {
    let data = vec!['a', 'b', 'c', 'd', 'e'];
    //           0    1    2    3    4
    
    /*
    Index:  0    1    2    3    4
    Data: ['a', 'b', 'c', 'd', 'e']
    
    &data[start..end] means:
    - Include elements FROM index start
    - Include elements UP TO (but NOT including) index end
    */
    
    let s1 = &data[0..3];  // Indices 0, 1, 2 → ['a', 'b', 'c']
    let s2 = &data[1..4];  // Indices 1, 2, 3 → ['b', 'c', 'd']
    let s3 = &data[2..5];  // Indices 2, 3, 4 → ['c', 'd', 'e']
    let s4 = &data[1..3];  // Indices 1, 2    → ['b', 'c']
    
    println!("s1: {:?}", s1);  // ['a', 'b', 'c']
    println!("s2: {:?}", s2);  // ['b', 'c', 'd']
    println!("s3: {:?}", s3);  // ['c', 'd', 'e']
    println!("s4: {:?}", s4);  // ['b', 'c']
    
    // Shorthand notations:
    let s5 = &data[..3];   // Same as &data[0..3]
    let s6 = &data[2..];   // Same as &data[2..5]
    let s7 = &data[..];    // Same as &data[0..5]
}

// ============================================
// PART 4: Slice Types - Different Kinds
// ============================================

fn slice_types() {
    // Type 1: Immutable slice of integers
    let numbers = vec![1, 2, 3, 4, 5];
    let slice: &[i32] = &numbers[..];
    //         ^^^^^^^
    //         Type: &[i32] (immutable slice of i32)
    
    // Can read:
    println!("First: {}", slice[0]);
    
    // Can't modify:
    // slice[0] = 100;  // ✗ ERROR
    
    // Type 2: Mutable slice of integers
    let mut numbers = vec![1, 2, 3, 4, 5];
    let slice: &mut [i32] = &mut numbers[..];
    //         ^^^^^^^^^^^^^^
    //         Type: &mut [i32] (mutable slice of i32)
    
    // Can read AND modify:
    println!("First: {}", slice[0]);
    slice[0] = 100;  // ✓ Can modify
    println!("Modified: {:?}", numbers);  // [100, 2, 3, 4, 5]
    
    // Type 3: Slice of strings (string slice)
    let text = String::from("hello");
    let slice: &str = &text[..];
    //         ^^^^
    //         Type: &str (string slice, not &[char])
    
    let partial: &str = &text[0..3];  // "hel"
    println!("Text slice: {}", partial);
}

// ============================================
// PART 5: String Slices - Special Case
// ============================================

fn string_slices() {
    let text = String::from("hello world");
    //  ^^^^
    //  Owned String
    
    // String slice: &str
    let slice1 = &text[..];      // "hello world"
    let slice2 = &text[0..5];    // "hello"
    let slice3 = &text[6..];     // "world"
    let slice4 = &text[0..5];    // "hello"
    
    println!("Full: {}", slice1);
    println!("First 5: {}", slice2);
    println!("After 6: {}", slice3);
    println!("Partial: {}", slice4);
    
    // String literals are also slices!
    let literal = "hello";
    //  ^^^^^^^
    //  Type: &str (already a slice)
    
    fn takes_string_slice(s: &str) {
        println!("Got: {}", s);
    }
    
    takes_string_slice(&text);     // ✓ String can be sliced
    takes_string_slice(literal);   // ✓ &str is a slice
    takes_string_slice(&text[0..5]); // ✓ Part of string
}

// ============================================
// PART 6: Slices Don't Own Data
// ============================================

fn ownership_example() {
    let vec = vec![1, 2, 3, 4, 5];
    //  ^^^
    //  OWNER of the data
    
    let slice = &vec[1..4];
    //  ^^^^^
    //  BORROWER - does NOT own the data
    
    // You can still use vec:
    println!("Vec: {:?}", vec);  // ✓ Works
    
    // Slice points to vec's data:
    println!("Slice: {:?}", slice);  // ✓ Works
    
    // But if you try to drop vec while slice exists:
    // drop(vec);
    // println!("{:?}", slice);  // ✗ ERROR! vec was dropped
    
    // Slice owns no data - it just references vec's data
    // When vec is dropped, slice becomes invalid
}

// ============================================
// PART 7: Using Slices in Functions
// ============================================

// Function takes a slice (flexible!)
fn sum_slice(numbers: &[i32]) -> i32 {
    //          ^^^^^^^
    //          Can accept ANY length!
    let mut total = 0;
    for &n in numbers {
        total += n;
    }
    total
}

fn average_slice(numbers: &[i32]) -> f64 {
    if numbers.is_empty() {
        return 0.0;
    }
    sum_slice(numbers) as f64 / numbers.len() as f64
}

fn slice_in_functions() {
    let vec1 = vec![1, 2, 3];
    let vec2 = vec![10, 20, 30, 40, 50];
    let array = [100, 200, 300];
    
    // All work! Same function, different data sizes
    println!("Sum vec1: {}", sum_slice(&vec1));        // 6
    println!("Sum vec2: {}", sum_slice(&vec2));        // 150
    println!("Sum array: {}", sum_slice(&array));      // 600
    
    // Partial slices work too
    println!("Sum vec2[1..3]: {}", sum_slice(&vec2[1..3]));  // 50
    
    println!("Avg vec1: {}", average_slice(&vec1));    // 2.0
    println!("Avg vec2: {}", average_slice(&vec2));    // 30.0
}

// ============================================
// PART 8: Modifying Data Through Slices
// ============================================

fn modifying_through_slices() {
    let mut data = vec![1, 2, 3, 4, 5];
    //  ^^^
    //  Must be mutable
    
    // Create a mutable slice
    let slice = &mut data[1..4];
    //  ^^^^^
    //  Mutable slice
    
    // Modify through the slice
    slice[0] = 20;  // Changes data[1]
    slice[1] = 30;  // Changes data[2]
    slice[2] = 40;  // Changes data[3]
    
    println!("Modified: {:?}", data);  // [1, 20, 30, 40, 5]
    
    // Function that modifies
    fn double_all(slice: &mut [i32]) {
        for x in slice {
            *x *= 2;
        }
    }
    
    double_all(&mut data[..]);
    println!("Doubled: {:?}", data);  // [2, 40, 60, 80, 10]
}

// ============================================
// PART 9: Slice Methods
// ============================================

fn slice_methods() {
    let data = vec![1, 2, 3, 4, 5];
    let slice = &data[1..4];
    //  ^^^^^
    
    // Length of slice
    println!("Length: {}", slice.len());  // 3
    
    // Is it empty?
    println!("Empty? {}", slice.is_empty());  // false
    
    // Get first element
    println!("First: {:?}", slice.first());  // Some(2)
    
    // Get last element
    println!("Last: {:?}", slice.last());  // Some(4)
    
    // Get element at index
    println!("At 0: {:?}", slice.get(0));  // Some(2)
    
    // Check if contains value
    println!("Contains 3? {}", slice.contains(&3));  // true
    
    // Iterate
    for &x in slice {
        print!("{} ", x);  // 2 3 4
    }
    
    // Sum (only for numeric slices)
    let nums = vec![10, 20, 30];
    let s: &[i32] = &nums;
    println!("Sum: {}", s.iter().sum::<i32>());  // 60
}

// ============================================
// PART 10: When NOT to Use Slices
// ============================================

fn when_not_slices() {
    // DON'T use slices if you need to OWN the data:
    fn needs_ownership(data: Vec<i32>) {
        // Owns the vector
        // Can modify, grow, shrink, etc.
        println!("Owned: {:?}", data);
    }
    
    // DO use slices if you just need to READ/BORROW:
    fn just_reading(data: &[i32]) {
        // Just borrowing
        // Can read, can't modify (unless &mut)
        println!("Borrowed: {:?}", data);
    }
}

// ============================================
// PART 11: VISUAL SUMMARY
// ============================================

fn visual_summary() {
    /*
    VECTOR:
    let vec = vec![1, 2, 3, 4, 5];
    ┌────────────────────────────────┐
    │ [1, 2, 3, 4, 5]                │
    │ 0  1  2  3  4 (indices)        │
    └────────────────────────────────┘
    You own this
    
    SLICE [1..4]:
    let slice = &vec[1..4];
    ┌────────────────────────────────┐
    │ [1, 2, 3, 4, 5]                │
    │    ↑        ↑                  │
    │    └────────┘                  │
    │   This part: [2, 3, 4]         │
    └────────────────────────────────┘
    You DON'T own this, just looking
    
    ANOTHER SLICE [2..]:
    let slice2 = &vec[2..];
    ┌────────────────────────────────┐
    │ [1, 2, 3, 4, 5]                │
    │       ↑           ↑            │
    │       └───────────┘            │
    │      This part: [3, 4, 5]      │
    └────────────────────────────────┘
    You DON'T own this, just looking
    */
}

fn main() {
    println!("=== What is a Slice ===");
    what_is_slice();
    
    println!("\n=== Creating Slices ===");
    creating_slices();
    
    println!("\n=== Slice Notation ===");
    slice_notation();
    
    println!("\n=== In Functions ===");
    slice_in_functions();
    
    println!("\n=== String Slices ===");
    string_slices();
    
    println!("\n=== Slice Methods ===");
    slice_methods();
}
