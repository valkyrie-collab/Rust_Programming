# Slices - Visual Guide

## What is a Slice?

A **slice** is a **reference to a contiguous sequence** of elements in an existing collection, without taking ownership.

```
Think of it like a WINDOW or VIEW into existing data
```

## Simple Example

### Without Slice
```rust
let vec = vec![1, 2, 3, 4, 5];
// You have the whole vector
// You own all 5 elements
```

### With Slice
```rust
let slice = &vec[1..4];
// You're looking at only elements at indices 1, 2, 3
// You DON'T own them, just borrowing the view
// slice contains: [2, 3, 4]
```

---

## Visual Representation

### The Vector

```
vec = vec![1, 2, 3, 4, 5];

Index:  0   1   2   3   4
Data: [1,  2,  3,  4,  5]
```

### Creating Slices

```
Slice 1: &vec[1..4]
Index:  0   1   2   3   4
Data: [1,  2,  3,  4,  5]
           ↑   ↑   ↑
           └─ slice ─┘
Result: [2, 3, 4]


Slice 2: &vec[0..3]
Index:  0   1   2   3   4
Data: [1,  2,  3,  4,  5]
       ↑   ↑   ↑
       └─ slice ┘
Result: [1, 2, 3]


Slice 3: &vec[2..]
Index:  0   1   2   3   4
Data: [1,  2,  3,  4,  5]
               ↑   ↑   ↑
               └─ slice ┘
Result: [3, 4, 5]


Slice 4: &vec[..3]
Index:  0   1   2   3   4
Data: [1,  2,  3,  4,  5]
       ↑   ↑   ↑
       └─ slice ┘
Result: [1, 2, 3]
```

---

## Slice Notation: [start..end]

```
&vec[1..4] means:
  │      └─ END index (NOT included)
  └─ START index (included)

Example:
vec = [10, 20, 30, 40, 50]
       0   1   2   3   4

&vec[1..4] = [20, 30, 40]
            indices 1, 2, 3 (but NOT 4)
```

### All Notations

```
&vec[1..4]   = Start 1, end 4 (not included)    → [element at 1,2,3]
&vec[1..]    = Start 1, to end                   → [1 onwards]
&vec[..4]    = Start 0, end 4 (not included)    → [0,1,2,3]
&vec[..]     = Entire array                      → [all]
```

---

## Two Parts to a Slice

A slice `&[i32]` has two pieces of information:

```
┌─────────────────┐
│ pointer: ─────┐ │  Points to the data
│ length: 3     │ │  How many elements
└─────────┬───────┘
          │
          ↓
      [2, 3, 4]
```

---

## Types of Slices

### Immutable Slice: &[i32]

```rust
let vec = vec![1, 2, 3, 4, 5];
let slice: &[i32] = &vec[1..4];

Can READ:
    println!("{}", slice[0]);  // ✓ Works

Can't MODIFY:
    slice[0] = 100;  // ✗ ERROR!
```

### Mutable Slice: &mut [i32]

```rust
let mut vec = vec![1, 2, 3, 4, 5];
let slice: &mut [i32] = &mut vec[1..4];

Can READ:
    println!("{}", slice[0]);  // ✓ Works

Can MODIFY:
    slice[0] = 100;  // ✓ Works!
```

### String Slice: &str

```rust
let text = String::from("hello");
let slice: &str = &text[0..3];  // "hel"

String slices are special - they use &str type
```

---

## Ownership: Key Difference

### Vector - YOU OWN the data

```rust
let vec = vec![1, 2, 3, 4, 5];
     ^^^
     OWNER

┌────────────────────────┐
│ [1, 2, 3, 4, 5]       │ ← You own this
└────────────────────────┘
```

### Slice - YOU DON'T OWN the data

```rust
let slice = &vec[1..4];
     ^^^^^
     BORROWER (doesn't own)

   vec's data:
┌────────────────────────┐
│ [1, 2, 3, 4, 5]       │ ← vec still owns this
└────────────────────────┘
     ↑        ↑
     └ slice ─┘ ← slice just points to a part
```

**Important:** If vec is dropped, slice becomes invalid!

---

## Why Use Slices? - Flexibility

### Without Slices (Rigid)

```rust
fn sum(vec: Vec<i32>) -> i32 {
    // Only accepts vectors!
    // Works: vec![1,2,3]
    // Fails: [1,2,3] (array)
    // Fails: &vec[1..3] (slice)
}
```

### With Slices (Flexible)

```rust
fn sum(slice: &[i32]) -> i32 {
    // Accepts ANY sequence!
    // Works: &vec![1,2,3]  (vector)
    // Works: &[1,2,3]      (array)
    // Works: &vec[1..3]    (partial)
    // Works: &vec[..]      (full)
}
```

---

## Real Example: Processing Data

```rust
let data = vec![10, 20, 30, 40, 50];

// Without slices - would need to handle each case
fn sum_vec(v: Vec<i32>) -> i32 { /* ... */ }
fn sum_array(a: [i32; 5]) -> i32 { /* ... */ }
fn sum_partial(...) { /* ... */ }

// With slices - ONE function handles all!
fn sum(s: &[i32]) -> i32 {
    s.iter().sum()
}

// All work:
sum(&data);           // ✓ Vector
sum(&data[1..4]);     // ✓ Partial vector
sum(&[1, 2, 3]);      // ✓ Array literal
```

---

## Common Slice Methods

```rust
let data = vec![1, 2, 3, 4, 5];
let slice = &data[1..4];  // [2, 3, 4]

// Length
slice.len()           // 3

// Check empty
slice.is_empty()      // false

// Get element
slice.get(0)          // Some(&2)
slice[0]              // 2 (panic if out of bounds)

// First/last
slice.first()         // Some(&2)
slice.last()          // Some(&4)

// Contains
slice.contains(&3)    // true

// Iterate
for &x in slice { }   // 2, 3, 4
```

---

## Slices and Strings

### String (owned)

```rust
let text = String::from("hello");
     ^^^^
     Owns the string data
```

### String Slice (&str)

```rust
let slice = &text[0..3];
            "hel"

let literal = "hello";
              ^^^^^^
              Already a &str (slice, not owned)
```

### Why Both?

```rust
fn process(s: &str) {
    // Accepts both String and &str!
}

let owned = String::from("hello");
let literal = "world";

process(&owned);   // ✓ Works (String coerces to &str)
process(literal);  // ✓ Works (&str directly)
```

---

## Memory Layout

### Vector + Slice

```
Stack:                           Heap:
┌──────────────────┐        ┌────────────────┐
│ vec:             │        │ [1, 2, 3, 4, 5]│
│ ptr ────────────┼────────→│                │
│ capacity: 5      │        └────────────────┘
│ length: 5        │
└──────────────────┘

┌──────────────────┐
│ slice:           │
│ ptr ────────┐    │
│ length: 3   │    │ Points to part of vec's data
└──────┬──────────┘
       │
       ↓
    [2, 3, 4] (inside vec's heap data)
```

---

## Summary Table

```
┌─────────────────────┬──────────────┬──────────────────┐
│ Aspect              │ Vector       │ Slice            │
├─────────────────────┼──────────────┼──────────────────┤
│ What is it?         │ Owned data   │ Reference        │
├─────────────────────┼──────────────┼──────────────────┤
│ Type                │ Vec<i32>     │ &[i32]           │
├─────────────────────┼──────────────┼──────────────────┤
│ Own data?           │ ✓ Yes        │ ✗ No             │
├─────────────────────┼──────────────┼──────────────────┤
│ Can grow/shrink?    │ ✓ Yes        │ ✗ No             │
├─────────────────────┼──────────────┼──────────────────┤
│ Fixed size?         │ ✗ No         │ ✓ Yes (known)    │
├─────────────────────┼──────────────┼──────────────────┤
│ Memory size         │ 24 bytes     │ 16 bytes         │
│                     │ (ptr+cap+len)│ (ptr+len)        │
├─────────────────────┼──────────────┼──────────────────┤
│ Can modify?         │ ✓ Yes (mut)  │ If &mut          │
├─────────────────────┼──────────────┼──────────────────┤
│ Use when            │ Need to own  │ Just need to     │
│                     │ Can expand   │ reference/borrow │
└─────────────────────┴──────────────┴──────────────────┘
```

---

## Key Takeaways

### What is a Slice?

```
A REFERENCE to a contiguous part of existing data
```

### Three Key Points

```
1. BORROWS data (doesn't own)
2. CONTIGUOUS (elements are next to each other)
3. FLEXIBLE (works with any source)
```

### When to Use

```
Use Slice (&[T]) when:
✓ You only need to READ or BORROW data
✓ You want to work with ANY size collection
✓ You're writing generic, reusable functions
✓ You don't need to own or modify the size

Use Vector (Vec<T>) when:
✓ You need to OWN the data
✓ You need to grow/shrink the collection
✓ You need exclusive access to modify
```

---

## Quick Examples

### Example 1: Function with Slice

```rust
fn first_three(data: &[i32]) -> Option<i32> {
    if data.len() >= 3 {
        Some(data[2])
    } else {
        None
    }
}

// Works with vector:
let vec = vec![1, 2, 3, 4, 5];
first_three(&vec);  // ✓

// Works with array:
let arr = [1, 2, 3];
first_three(&arr);  // ✓

// Works with partial:
first_three(&vec[1..4]);  // ✓
```

### Example 2: Mutable Slice

```rust
fn double_all(data: &mut [i32]) {
    for x in data {
        *x *= 2;
    }
}

let mut vec = vec![1, 2, 3];
double_all(&mut vec);
println!("{:?}", vec);  // [2, 4, 6]
```

🎯 **Slices = Flexible references to parts of data!**
